<?php

session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.html");
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet"/>
    <!-- Boxicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.core.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.theme.css">
    <!-- Glide js -->
    <link rel="preconnect" href="https://fonts.googleapis.com">  
     <!-- google fonts-->
    <link rel="stylesheet" href="./css/styles.css" />
    <!-- icon library(star)-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Tease_Trendz</title>
  </head>


<body>
    <!-- Header -->
    <header class="header" id="header">
      <!--Nav 1 -->
      <div class="top-nav">
        <div class="container d-flex">
          <p> </p>
          <ul class="d-flex">
            <li><a href="about.html">About Us</a></li>
            <li><a href="contact.html">FAQ</a></li>
            <li><a href="contact.html">Contact Us</a></li>
          </ul>
        </div>
      </div>
      <!-- Nav 2-->
      <div class="navigation">
        <div class="nav-center container d-flex">
        <a href="index.html" class="logo"><h1>Tease_Trendz</h1></a>

          <ul class="nav-list d-flex">
            <li class="nav-item">
              <a href="index.php" class="nav-link">Home</a>
            </li>
            <li class="nav-item">
              <a href="product2.html" class="nav-link">Trends</a>
            </li>
            <li class="nav-item">
            <a href="product.html" class="nav-link">Shop</a>
          </li>
            <li class="nav-item">
              <a href="about.html" class="nav-link">About Us</a>
            </li>
            <li class="nav-item">
              <a href="contact.html" class="nav-link">Contact Us</a>
            </li>
            <li class="nav-item">
                <a href="profile.php" class="nav-link"><?php echo "Welcome " . $_SESSION['name'] ?></a>
            </li>
        </ul>

        <div class="icons d-flex">
            <a href="login.html" class="icon">
              <i class="bx bx-user"></i>
            </a>
            <a href="search.html" class="icon">
            <i class="bx bx-search"></i>
                </a>
            <div class="icon" >
              <i class="bx bx-heart"></i>
              <span class="d-flex">0</span>
            </div>
            <a href="cart.html" class="icon">
              <i class="bx bx-cart"></i>
              <span class="d-flex">0</span>
            </a>
            <a href="logout.php" class="icon">
              <i class="bx bx-log-out"></i>
            </a>
          </div>

          <div class="hamburger">
            <i class="bx bx-menu-alt-left"></i>
          </div>
        </div>
      </div>

    <div class="hero">
      <div class="glide" id="glide_1">
        <div class="glide__track" data-glide-el="track">
          <ul class="glide__slides">
            <li class="glide__slide">
              <div class="center">
                <div class="left">
                  <h1 class="">SET THE TREND!</h1>
                  <p>Unveil the latest collection
                    </p> 
                  <a href="product.html" class="hero-btn">SHOP NOW</a>
                </div>
                <div class="right">
                    <img class="img1" src="./images/banner.png" alt="">
                </div>
              </div>
            </li>
            <li class="glide__slide">
              <div class="center">
                <div class="left">
                  <h1>MAKE EVERY OUTFIT<br> COUNT</h1>
                  <p>Trending from men's and women's  style collection</p>
                  <a href="product.html" class="hero-btn">SHOP NOW</a>
                </div>
                <div class="right">
                  <img class="img2" src="./images/main4.png" alt="">
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    </header>

    <!-- Categories  -->
    <section class="section category">
      <div class="title">
        <h1>LET'S EXPLORE</h1>
      </div>
      <div class="cat-center">
        <div class="cat">
          <img src="./images/Categories/cat3.jpg" alt="" />
          <div class="cat-p">
            <p>WOMEN'S WEAR</p>
          </div>
        </div>        
        <div class="cat">
          <img src="./images/Categories/cat4.jpeg" alt="" />
          <div class="cat-p">
            <p>MEN'S WEAR</p>
          </div>
        </div>
        <div class="cat">
          <img src="./images/Categories/cat5.jpg" alt="" />
          <div class="cat-p">
            <p>KID'S SECTION</p>
          </div>
        </div>
      </div>
    </section>

    <!-- New Arrivals -->
    <section class="section new-arrival">
      <div class="title">
        <h1>NEW ARRIVALS</h1>
        <p>All the latest selections handpicked by the designers of our store.</p>
      </div>

      <div class="product-center">
        <div class="product-item">
          <div class="overlay">
            <a href="productDetails.html" class="product-thumb">
              <img src="./images/Products/prod1.webp" alt="" />
            </a>
          </div>
          <div class="product-info">
            <span>WOMEN'S CLOTHING</span>
            <a href="productDetails.html">Floral printed maxi</a>
            <div class="star">
              <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span>
            </div>
            <h4>Rs. 900</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/Products/prod2.jpg" alt="" />
            </a>
            <!-- <span class="discount">50%</span> -->
          </div>

          <div class="product-info">
            <span>MEN'S CLOTHING</span>
            <a href="">Men fancy blue coat</a>
            <div class="star">
              <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span>
            </div>
            <h4>Rs.1100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/Products/prod3.avif" alt="" />
            </a>
          </div>
          <div class="product-info">
            <span>WOMEN'S CLOTHING</span>
            <a href="">Printed shiffon saree</a>
            <div class="star">
              <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
            </div>
            <h4>Rs.1500</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/Products/prod4.jpg" alt="" />
            </a>
            <!-- <span class="discount">50%</span> -->
          </div>
          <div class="product-info">
            <span>MEN'S CLOTHING</span>
            <a href="">cream t-shirt full-sleeve</a>
            <div class="star">
              <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star "></span>
        <span class="fa fa-star"></span>
            </div>
            <h4>Rs.499</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/Products/prod5.jpg" alt="" />
            </a>
          </div>
          <div class="product-info">
            <span>PRODUCT</span>
            <a href="">latest trend</a>
            <div class="star">
              <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star "></span>
            </div>
            <h4>Rs.100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/Products/prod6.avif" alt="" />
            </a>
          </div>
          <div class="product-info">
            <span>PRODUCT</span>
            <a href="">latest trend</a>
            <div class="star">
              <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star "></span>
            </div>
            <h4>Rs.100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/Products/prod7.jpg" alt="" />
            </a>
            <!-- <span class="discount">50%</span> -->
          </div>
          <div class="product-info">
            <span>PRODUCT</span>
            <a href="">latest trend</a>
            <div class="star">
              <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star "></span>
            </div>
            <h4>Rs.100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/Products/prod8.jpeg" alt="" />
            </a>
          </div>
          <div class="product-info">
            <span>PRODUCT</span>
            <a href="">latest trend</a>
            <div class="star">
              <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star "></span>
            </div>
            <h4>Rs.100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
      </div>
    </section>


    <!-- Promo -->

    <section class="section banner">
<div class="left">
  <span class="trend">Sale 50% OFF</span>
  <h1>Off Season Shop</h1>
  <p>Enjoy discounts on off-season clothing!<br><br>Limited Time Offer</p>
  <a href="product.html" class="btn btn-1">Discover Now</a>
</div>
<div class="right">
  <img src="./images/off2.png" alt="">
</div>
    </section>




    <!-- Featured -->
  
    <section class="section new-arrival">
      <div class="title">
        <h1>Featured</h1>
        <!-- <p>All the latest picked from designer of our store</p> -->
      </div>

      <div class="product-center">
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/featured/f1.webp" alt="" />
            </a>
            <!-- <span class="discount">50%</span> -->
          </div>
          <div class="product-info">
            <span>PRODUCT</span>
            <a href="">latest trend</a>
            <h4>Rs.100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/featured/f2.webp" alt="" />
            </a>
          </div>

          <div class="product-info">
            <span>PRODUCT</span>
            <a href="">latest trend</a>
            <h4>Rs.100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/featured/f3.jpg" alt="" />
            </a>
            <!-- <span class="discount">40%</span> -->
          </div>
          <div class="product-info">
            <span>PRODUCT</span>
            <a href="">latest trend</a>
            <h4>Rs.100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>
        <div class="product-item">
          <div class="overlay">
            <a href="" class="product-thumb">
              <img src="./images/featured/f4.webp" alt="" />
            </a>
          </div>
          <div class="product-info">
            <span>PRODUCT</span>
            <a href="">latest trend</a>
            <h4>Rs.100</h4>
          </div>
          <ul class="icons">
            <li><i class="bx bx-heart"></i></li>
            <li><i class="bx bx-cart"></i></li>
            <li><i class="bx bx-share bx-flip-horizontal"></i></li>
          </ul>
        </div>

    </section>

    <!-- Contact -->
    <section class="section contact">
      <div class="row">
        <div class="col">
          <h2>24*7 SUPPORT</h2>
          <p> We deeply value our customers and are committed to being available round-the-clock to assist you.</p>
          <a href="contact.html" class="btn btn-1">Contact Us</a>
        </div>
        <div class="col">
          <form action="">
            <div>
              <input type="email" placeholder="Email Address">
            <a href="">Send</a>
            </div>
          </form>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
      <div class="row">
        <div class="col d-flex">
          <h4>INFORMATION</h4>
          <a href="about.html">About Us</a>
          <a href="contact.html">Contact Us</a>
          <a href="terms.html">Term & Conditions</a>
          <!-- <a href="">Shipping Guide</a> -->
        </div>
        <div class="col d-flex">
          <h4>USEFUL LINK</h4>
          <a href="">Online Store</a>
          <a href="">Customer Services</a>
          <a href="">FAQs</a>
          <a href="">Top Brands</a>
        </div>
        <div class="col d-flex">
          <span><i class='bx bxl-facebook-square'></i></span>
          <span><i class='bx bxl-instagram-alt' ></i></span>
          <span><i class='bx bxl-github' ></i></span>
          <span><i class='bx bxl-twitter' ></i></span>
          <span><i class='bx bxl-pinterest' ></i></span>
        </div>
      </div>
    </footer>


  <!-- PopUp -->
  <div class="popup hide-popup">
    <div class="popup-content">
      <div class="popup-close">
        <i class='bx bx-x'></i>
      </div>
      <div class="popup-left">
        <div class="popup-img-container">
          <img class="popup-img" src="./images/newsletter/new4.avif" alt="popup">
        </div>
      </div>
      <div class="popup-right">
        <div class="right-content">
          <h1 >Get latest offer updates </h1>
          </p>
          <form action="#">
            <input type="email" placeholder="Enter your email..." class="popup-form">
            <input type="tel" placeholder="Enter your mobile number..." class="popup-form">
            <a href="#">Subscribe</a>
          </form>
        </div>
      </div>
    </div>
  </div>

  </body>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/glide.min.js"></script>
  <script src="./js/slider.js"></script>
  <script src="./js/index.js"></script>
</html>
